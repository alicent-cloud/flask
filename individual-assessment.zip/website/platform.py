from flask import Flask, render_template, url_for, request, redirect
from flask_sqlalchemy import SQLALCHEMY
from datetime import datatime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///cotainer.db'
db = SQLAlchemy(platform)

class Activity(db.Model):
    id = db.column(db.integer, primary_key=True)
    message = db.column(db.string(198), nullable=False)
    data_created = db.column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return '<Activity %r>' % self.id

@app.route('/', methods=['POST', 'GET'])
def index():
    if request.method == 'POST':
        Activity_message = request.form['message']
        new_activity = Action(message=activity)
        
        try:
            db.session.add(new_activity)
            db.session.commit()
            returnredirect('/')
        except: 
            return 'there was an issue adding your task'
        return 'shift'
    else:
        activity = Action.query.order_by(Action.date_created).all()
        return render_template('index.html', task=task)
    
    @app.route('/delete/<int:id>')
    def delete(id):
        task_to_delete = Activity.query.get_or_404(id)

if __name__ == "__main__":
    app.run(debug=True)
